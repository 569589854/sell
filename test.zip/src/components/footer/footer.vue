<template>
    <div class="footer">
      <shopcart></shopcart>
    </div>
</template>

<script>
  import shopcart from 'components/shopcart/shopcart'
    export default {
      data(){
        return{

        }
      },
      components: {
        shopcart
      }
    }
</script>

<style scoped>

</style>
